/* eslint-disable prettier/prettier */
export default function index({name,style}) {
  return (
    <ion-icon name={name} style={style}></ion-icon>
  )
}
