// @mui material components
import Card from '@mui/material/Card';

function Projects() {
  return <Card></Card>;
}

export default Projects;
