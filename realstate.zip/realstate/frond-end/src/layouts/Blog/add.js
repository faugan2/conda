import { apiConstants } from 'API/apiConstrants';
import React, { useState } from 'react';

function AddBlogForm({close,successAlert,loadBlogs}) {
  const [picture, setPicture] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [section, setSection] = useState('');
  const [readTime, setReadTime] = useState('');
  const [file,set_file]=useState(null);

  const  handleSubmit=async (event) =>{
    event.preventDefault();
    const calculatedReadTime = Math.ceil(description.split(' ').length / 200);

    const data={
        picture,
        title,
        description,
        section,
        file,
        readTime: `${calculatedReadTime} minute${calculatedReadTime !== 1 ? 's' : ''}`
    };

    let method;
    method = 'POST';
    var myHeaders = new Headers();
    myHeaders.append('Content-Type', 'application/json');

    
    
    var fd=new FormData()
    fd.append('picture',file)
    fd.append('title',title)
    fd.append('description',description)
    fd.append('section',section)
    fd.append('readTime',readTime)

    var requestOptions = {
      method: method,
      body: fd
    };

    fetch(apiConstants.ADD_BLOG, requestOptions).then(async (response) => {
        const res=await response.json();
        console.log("the response is",res)
        setPicture('');
        setTitle('');
        setDescription('');
        setSection('');
        setReadTime('');

        close()
        successAlert("Hi it is done")
        loadBlogs()
    })

    
    
  }

  function handleInputChange(event) {
    const target = event.target;
    const name = target.name;
    const value = target.value;
    if (name === 'picture') {
      setPicture(value);
    } else if (name === 'title') {
      setTitle(value);
    } else if (name === 'description') {
      setDescription(value);
      const calculatedReadTime = Math.ceil(value.split(' ').length / 200);
      setReadTime(`${calculatedReadTime} minute${calculatedReadTime !== 1 ? 's' : ''}`);
    } else if (name === 'section') {
      setSection(value);
    }
  }

  const file_changed=(event)=>{
    const files=event.target.files;
    if(files.length==0) return;

    const file=files[0];
    set_file(file)
  }

  return (
    <form onSubmit={handleSubmit} className="text-sm">
      
      <div className="flex flex-col mb-4">
        <label htmlFor="picture" className="font-bold">Picture:</label>
        <input
            type="file"
            id="picture"
            name="picture"
            onChange={file_changed}
        />
      </div>

      <div className="flex flex-col mb-4">
        <label htmlFor="title" className="font-bold">Title:</label>
        <input
            className='border p-1 outline-none'
            type="text"
            id="title"
            name="title"
            value={title}
            onChange={handleInputChange}
        />
      </div>
      
        <div className="flex flex-col mb-4">
        <label htmlFor="description" className="font-bold">Blog description:</label>
        <textarea
        className='border outline-none p-1'
            id="description"
            name="description"
            value={description}
            onChange={handleInputChange}
        ></textarea>
        </div>
      
        <div className="flex flex-col mb-4">
        <label htmlFor="section" className="font-bold">Section:</label>
        <input
        className='border outline-none p-1'
        type="text"
        id="section"
        name="section"
        value={section}
        onChange={handleInputChange}
        />
        </div>
      
        <div className="flex flex-col mb-4">
        <label htmlFor="read-time" className="font-bold">Read time:</label>
        <input
            className='border-none p-1 outline-none'
            type="text"
            id="read-time"
            name="read-time"
            value={readTime}
            readOnly
        />
        </div>
      
        <div className='flex justify-end'>
        <button type="submit"
        className="bg-blue-500 p-2 w-[100px] rounded-md hover:opacity-80 cursor-pointer text-white font-bold"
        >Add</button>
        </div>
      
    </form>
  );
}

export default AddBlogForm;
