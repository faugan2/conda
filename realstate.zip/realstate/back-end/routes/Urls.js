const REQUEST_URL = 'http://localhost:3000';

module.exports.REQUEST_URL = REQUEST_URL;
